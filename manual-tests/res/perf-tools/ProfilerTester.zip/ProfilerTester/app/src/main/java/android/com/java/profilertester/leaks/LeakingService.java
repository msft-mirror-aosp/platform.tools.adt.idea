/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.com.java.profilertester.leaks;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;

public class LeakingService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("LeakSample", "Entering " + getClass().getSimpleName());

        GlobalLeakingObject.leakedServices.add(this);
        GlobalLeakingObject.logCurrentLeaks();

        new Handler(Looper.getMainLooper()).postDelayed(this::stopSelf, 1000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("LeakSample", "Exiting " + getClass().getSimpleName());
    }

    public static class LS1 extends LeakingService {}

    public static class LS2 extends LeakingService {}

    public static class LS3 extends LeakingService {}

    public static class LS4 extends LeakingService {}

    public static class LS5 extends LeakingService {}
}
